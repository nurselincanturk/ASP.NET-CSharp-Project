﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace projeWeb
{
    public partial class yorum : System.Web.UI.Page
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=WebProje;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            FillGridView();
        }
        protected void btnSave_Click(object sender, EventArgs e)
        {


            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
            SqlCommand sqlCmd = new SqlCommand("goster", sqlCon);
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.Parameters.AddWithValue("@adsoyad", txtproduct.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@mail",txtPrice.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@mesaj", txtCount.Text.Trim());
            sqlCmd.ExecuteNonQuery();
            sqlCon.Close();
            

            FillGridView();

        }
        void FillGridView()
        {
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
            SqlDataAdapter sqlDa = new SqlDataAdapter("goster2", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            sqlCon.Close();
           gvProduct.DataSource = dtbl;
            gvProduct.DataBind();

        }
    }
}