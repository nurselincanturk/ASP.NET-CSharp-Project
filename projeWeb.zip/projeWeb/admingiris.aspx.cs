﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace projeWeb
{
    public partial class admingiris : System.Web.UI.Page
    {
        public int uyeid;
        SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=WebProje;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            

        }

       
        protected void kaydolbuton_Click(object sender, EventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }

            if (adtxt.Text=="istanbul")
            {
                SqlCommand sqlCmd = new SqlCommand("ekleist", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@baslik", basliktxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@resim", resimtxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@aciklama",aciklamatxt.Text.Trim());
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();

                lblSuccessMessage.Text = "Saved succesfully";
            }
            else if (adtxt.Text == "bursa")
            {
                SqlCommand sqlCmd = new SqlCommand("eklebur", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@baslik", basliktxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@resim", resimtxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@aciklama", aciklamatxt.Text.Trim());
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();

                lblSuccessMessage.Text = "Saved succesfully";
            }
            else if (adtxt.Text == "balıkesir")
            {
                SqlCommand sqlCmd = new SqlCommand("eklebal", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@baslik", basliktxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@resim", resimtxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@aciklama", aciklamatxt.Text.Trim());
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();

                lblSuccessMessage.Text = "Saved succesfully";
            }
            else if (adtxt.Text == "edirne")
            {
                SqlCommand sqlCmd = new SqlCommand("ekleedi", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@baslik", basliktxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@resim", resimtxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@aciklama", aciklamatxt.Text.Trim());
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();

                lblSuccessMessage.Text = "Saved succesfully";
            }
            else if (adtxt.Text == "tekirdağ")
            {
                SqlCommand sqlCmd = new SqlCommand("ekletek", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@baslik", basliktxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@resim", resimtxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@aciklama", aciklamatxt.Text.Trim());
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();

                lblSuccessMessage.Text = "Saved succesfully";
            }
            else if (adtxt.Text == "çanakkale")
            {
                SqlCommand sqlCmd = new SqlCommand("eklecan", sqlCon);
                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.AddWithValue("@baslik", basliktxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@resim", resimtxt.Text.Trim());
                sqlCmd.Parameters.AddWithValue("@aciklama", aciklamatxt.Text.Trim());
                sqlCmd.ExecuteNonQuery();
                sqlCon.Close();

                lblSuccessMessage.Text = "Saved succesfully";
            }





        }
    }
}