﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

namespace projeWeb
{
    /// <summary>
    /// WebService1 için özet açıklama
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // Bu Web Hizmeti'nin, ASP.NET AJAX kullanılarak komut dosyasından çağrılmasına, aşağıdaki satırı açıklamadan kaldırmasına olanak vermek için.
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

      

        [WebMethod]
        public string Hava_Durumu_Sorgulama(string Sehir)
        {
            if (Sehir == "istanbul")
            {
                return "Hava 13°C Yağmurlu.\nDışarı Çıkarken Şemsiyenizi unutmayınız.";
            }
            if (Sehir == "bursa")
            {
                return "Hava 14°C Parçalı Bulutlu.\nDışarı Çıkmak İçin Güzel Bir Gün.";
            }
            if (Sehir == "balıkesir")
            {
                return "Hava 9°C Sağanak Yağışlı.\nDışarı Çıkmak İçin Kötü Bir Gün.";
            }
            if (Sehir == "edirne")
            {
                return "Hava 7°C Kar Yağışlı.\nKar Manzarasının Keyfini Çıkarmak İstiyorsanız Sıkı Giyinmeyi Unutmayın.";
            }
            if (Sehir == "tekirdağ")
            {
                return "Hava 13°C Yağmurlu.\nGezinizde Şemsiyenizi unutmayınız.";

            }
            if (Sehir == "çanakkale")
            {
                return "Hava 16°C Güneşli.\nGezmek İçin Çok Güzel Bir Gün.";
            }
            else
            {
                return "Lütfen Geçerli Bir Marmara Bölgesi Şehri Giriniz.";
            }


        }
    
    }
}
