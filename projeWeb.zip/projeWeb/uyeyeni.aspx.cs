﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;


namespace projeWeb
{
    public partial class uyeyeni : System.Web.UI.Page
    {
        public int uyeid;
        SqlConnection sqlCon = new SqlConnection(@"Data Source=LAPTOP-VB4BVHDI\SQLEXPRESS;Initial Catalog=WebProje;Integrated Security=True");

        protected void Page_Load(object sender, EventArgs e)
        {
            lblerrorrmessages.Visible = false;

        }

        public void girisbuton_Click(object sender, EventArgs e)
        {
            using (sqlCon)
            {

                sqlCon.Open();
                SqlCommand command = new SqlCommand("UyeGiris", sqlCon);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@email", emailgiristxt.Text.Trim());
                command.Parameters.AddWithValue("@password", sifretxt.Text.Trim());
                int count = Convert.ToInt32(command.ExecuteScalar());
                if (count == 1)
                {
                    if (emailgiristxt.Text == "")
                    {
                        lblerrorrmessages.Visible = true;

                    }

                    else
                    {


                        if (emailgiristxt.Text == "adminim" && sifretxt.Text == "admin")
                        {
                            Session["email"] = emailgiristxt.Text.Trim();
                            Response.Redirect("admingiris.aspx");
                        }
                        else
                            Session["email"] = emailgiristxt.Text.Trim();
                             Response.Redirect("Anasayfa.aspx");



                    }




                }


                else
                    lblerrorrmessages.Visible = true;


            }
        }

        protected void kaydolbuton_Click(object sender, EventArgs e)
        {
            if (sqlCon.State == ConnectionState.Closed)
            {
                sqlCon.Open();
            }
            SqlCommand sqlCmd = new SqlCommand("uyeEkleGuncelle", sqlCon);
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.Parameters.AddWithValue("@userid", (hfuserID.Value == "" ? 0 : Convert.ToInt32(hfuserID.Value)));
            sqlCmd.Parameters.AddWithValue("@name", adtxt.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@lastname", soyadtxt.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@email", emailtxt.Text.Trim());
            sqlCmd.Parameters.AddWithValue("@password", TextBox21.Text.Trim());
            sqlCmd.ExecuteNonQuery();
            sqlCon.Close();

            if (hfuserID.Value == "")
            {
                lblSuccessMessage.Text = "Saved succesfully";
            }
            else
            {
                lblSuccessMessage.Text = "Update succesfully";
            }
            Clear();
            Response.Redirect("Anasayfa.aspx");



        }
        void Clear()
        {
            hfuserID.Value = "";
            adtxt.Text = soyadtxt.Text = emailtxt.Text = TextBox21.Text = "";
            lblSuccessMessage.Text = lblErrorMessage.Text;

            lblErrorMessage.Text = lblSuccessMessage.Text = "";
        }
    }
}